﻿using System;
using System.Collections.Generic;

namespace WinFormsApp1.Models;

public partial class MennyisegiEgysegek
{
    public int MennyisegiEgysegId { get; set; }

    public string? EgysegNev { get; set; }

    public virtual ICollection<Nyersanyagok> Nyersanyagoks { get; set; } = new List<Nyersanyagok>();
}
