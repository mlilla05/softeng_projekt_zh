﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1.Models;

namespace WinFormsApp1
{
    public partial class ReceptekForm : Form
    {
        private ReceptDbContext context;
        public ReceptekForm()
        {
            InitializeComponent();
            context = new ReceptDbContext();
        }

        private void ReceptekForm_Load(object sender, EventArgs e)
        {
            NyersanyagListazas();
            FogasListazas();
        }
        private void NyersanyagListazas()
        {
            var nyersanyagok = from x in context.Nyersanyagoks
                               where x.NyersanyagNev.Contains(textBox1.Text)
                               select x;

            nyersanyagokBindingSource.DataSource = nyersanyagok.ToList();
        }
        private void FogasListazas()
        {
            var fogasok = from x in context.Fogasoks
                          where x.FogasNev.Contains(textBox2.Text)
                          select x;

            fogasokBindingSource.DataSource = fogasok.ToList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            NyersanyagListazas();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            FogasListazas();
        }
        private void HozzavaloListazas()
        {
            if (listBox2.SelectedItem is Fogasok kivalasztottFogas)
            {
                var id = kivalasztottFogas.FogasId;

                var hozzavalok = from x in context.Recepteks
                                 where x.FogasId == id
                                 select new Hozzavalo
                                 {
                                     ReceptID = x.ReceptId,
                                     FogasID = x.FogasId,
                                     NyersanyagNev = x.Nyersanyag.NyersanyagNev,
                                     Mennyiseg_4fo = x.Mennyiseg4fo,
                                     EgysegNev = x.Nyersanyag.MennyisegiEgyseg.EgysegNev,
                                     Ár = x.Mennyiseg4fo * (double?)x.Nyersanyag.Egysegar
                                 };
                hozzavaloBindingSource.DataSource = hozzavalok.ToList();
            }
            else
            {
                hozzavaloBindingSource.DataSource = null; // vagy hozzavaloBindingSource.Clear();
            }
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            HozzavaloListazas();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var kivalasztottNyersanyag = (Nyersanyagok)listBox1.SelectedItem;
            if (kivalasztottNyersanyag != null)
            {
                var mennyiseg = (from x in context.MennyisegiEgysegeks
                                 where x.MennyisegiEgysegId == kivalasztottNyersanyag.MennyisegiEgysegId
                                 select x).FirstOrDefault();

                if (mennyiseg != null)
                {
                    label1.Text = mennyiseg.EgysegNev;
                }
                else
                {
                    label1.Text = "Nincs megadva mennyiségi egység";
                }
            }
            else
            {
                label1.Text = "";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReceptekHozzaadasForm ujHozzavalo = new ReceptekHozzaadasForm();

            if (ujHozzavalo.ShowDialog() == DialogResult.OK)
            {
                Receptek ujNyersanyag = new Receptek();
                ujNyersanyag.NyersanyagId = ((Nyersanyagok)ujHozzavalo.comboBox1.SelectedItem).NyersanyagId;
                ujNyersanyag.FogasId = ((Fogasok)listBox2.SelectedItem).FogasId;

                double mennyiseg;
                if (!double.TryParse(ujHozzavalo.textBox1.Text, out mennyiseg))
                {
                    MessageBox.Show("Kérlek, adj meg egy érvényes számot a mennyiséghez!");
                    return;
                }
                ujNyersanyag.Mennyiseg4fo = mennyiseg;

                context.Recepteks.Add(ujNyersanyag);
                context.SaveChanges();
                HozzavaloListazas();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (hozzavaloBindingSource.Current is not Hozzavalo torlendo)
            {
                MessageBox.Show("Nincs kiválasztott hozzávaló a törléshez!");
                return;
            }

            var torlendoRecept = (from x in context.Recepteks
                                  where x.ReceptId == torlendo.ReceptID
                                  select x).FirstOrDefault();

            if (torlendoRecept != null)
            {
                context.Recepteks.Remove(torlendoRecept);
                context.SaveChanges();

                HozzavaloListazas();
            }
            else
            {
                MessageBox.Show("A kiválasztott hozzávaló nem található az adatbázisban.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null || listBox2.SelectedItem == null)
            {
                MessageBox.Show("Kérlek, válassz ki egy nyersanyagot és egy fogást!");
                return;
            }

            Receptek r = new Receptek();
            r.NyersanyagId = ((Nyersanyagok)listBox1.SelectedItem).NyersanyagId;
            r.FogasId = ((Fogasok)listBox2.SelectedItem).FogasId;

            double m;
            if (!double.TryParse(textBox3.Text, out m))
            {
                MessageBox.Show("Kérlek, adj meg egy érvényes számot a mennyiséghez!");
                return;
            }

            r.Mennyiseg4fo = m;

            context.Recepteks.Add(r);
            context.SaveChanges();

            HozzavaloListazas();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (hozzavaloBindingSource.Current is not Hozzavalo torlendo)
            {
                MessageBox.Show("Nincs kiválasztott hozzávaló a törléshez!");
                return;
            }

            var torlendoRecept = (from x in context.Recepteks
                                  where x.ReceptId == torlendo.ReceptID
                                  select x).FirstOrDefault();

            if (torlendoRecept != null)
            {
                context.Recepteks.Remove(torlendoRecept);
                context.SaveChanges();

                HozzavaloListazas();
            }
            else
            {
                MessageBox.Show("A kiválasztott hozzávaló nem található az adatbázisban.");
            }
        }
    }
    public class Hozzavalo
    {
        public int ReceptID { get; set; }
        public int? FogasID { get; set; }
        public string NyersanyagNev { get; set; }
        public double? Mennyiseg_4fo { get; set; }
        public string EgysegNev { get; set; }
        public double? Ár { get; set; }
    }
}
