﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1.Models;

namespace WinFormsApp1
{
    public partial class ReceptekHozzaadasForm : Form
    {
        private ReceptDbContext context;
        public ReceptekHozzaadasForm()
        {
            InitializeComponent();
            context = new ReceptDbContext();
            nyersanyagokBindingSource.DataSource = context.Nyersanyagoks.ToList();
            mennyisegiEgysegekBindingSource.DataSource = context.MennyisegiEgysegeks.ToList();
        }

        private void ReceptekHozzaadasForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Kérlek, válassz ki egy nyersanyagot!");
                return;
            }

            if (!double.TryParse(textBox2.Text, out double mennyiseg))
            {
                MessageBox.Show("Kérlek, adj meg egy érvényes mennyiséget!");
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem is Nyersanyagok selectedNyersanyag)
            {
                comboBox2.SelectedValue = selectedNyersanyag.MennyisegiEgysegId;
                textBox2.Text = selectedNyersanyag.Egysegar.ToString();
            }
        }
    }
}
