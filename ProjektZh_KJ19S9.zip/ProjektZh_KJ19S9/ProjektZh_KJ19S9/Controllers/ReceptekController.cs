﻿using Microsoft.AspNetCore.Mvc;
using ProjektZh_KJ19S9.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProjektZh_KJ19S9.Controllers
{
    [Route("api/receptek")]
    [ApiController]
    public class ReceptekController : ControllerBase
    {
        // GET: api/<ReceptekController>
        [HttpGet]
        public IActionResult Get()
        {
            ReceptDbContext context = new ReceptDbContext();
            return Ok(context.MennyisegiEgysegeks.ToList());
        }

        // GET api/<ReceptekController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            ReceptDbContext context = new ReceptDbContext();
            var keresettME = (from x in context.MennyisegiEgysegeks
                              where x.MennyisegiEgysegId == id
                              select x).FirstOrDefault();
            if (keresettME == null)
            {
                return NotFound($"Nincs #{id} azonosítóval mennyiségi egység");
            }
            else
            {
                return Ok(keresettME);
            }
        }

        // POST api/<ReceptekController>
        [HttpPost]
        public void Post([FromBody] MennyisegiEgysegek ujMe)
        {
            ReceptDbContext context = new ReceptDbContext();
            var maxId = context.MennyisegiEgysegeks.Max(t => (int?)t.MennyisegiEgysegId) ?? 0;
            ujMe.MennyisegiEgysegId = maxId + 1;
            context.MennyisegiEgysegeks.Add(ujMe);
            context.SaveChanges();
        }

        // PUT api/<ReceptekController>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] MennyisegiEgysegek value)
        {
            try
            {
                ReceptDbContext context = new ReceptDbContext();
                var meModositas = (from x in context.MennyisegiEgysegeks
                                   where x.MennyisegiEgysegId == id
                                   select x).FirstOrDefault();
                if (meModositas == null)
                {
                    return NotFound("Nincs ilyen azonosítójú mennyiségi egység!");
                }

                meModositas.EgysegNev = value.EgysegNev;

                context.SaveChanges();

                return Ok(new
                {
                    message = "Sikeres módosítás!",
                    updatedME = meModositas
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba történt: {ex.Message}");
                return StatusCode(500, new { message = "Hiba történt a módosítás során.", error = ex.Message });
            }
        }

        // DELETE api/<ReceptekController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            ReceptDbContext context = new ReceptDbContext();
            var torlendoMe = (from x in context.MennyisegiEgysegeks
                              where x.MennyisegiEgysegId == id
                              select x).FirstOrDefault();
            if (torlendoMe == null)
            {
                return NotFound("Nincs ilyen");
            }
            context.Remove(torlendoMe);
            context.SaveChanges();
            return Ok("Sikeres törlés");
        }
    }
}
